let hindi = true;

document.getElementById("langToggle").addEventListener("click", () => {
  hindi = !hindi;
  document.getElementById("langToggle").textContent = hindi ? "🌐 English" : "🌐 हिंदी";
  document.getElementById("desc").textContent = hindi
    ? "नीचे बटन दबाकर अपनी prediction देखें"
    : "Press a button below to see your prediction";
});

function predict(type) {
  let result = "";
  if (type === "smallbig") {
    result = Math.random() < 0.5 ? (hindi ? "छोटा 🔵" : "Small 🔵") : (hindi ? "बड़ा 🔴" : "Big 🔴");
  } else if (type === "number") {
    const num = Math.floor(Math.random() * 100);
    result = (hindi ? "नंबर: " : "Number: ") + num;
  } else if (type === "color") {
    const colors = hindi
      ? ["लाल ❤️", "हरा 💚", "नीला 💙", "पीला 💛"]
      : ["Red ❤️", "Green 💚", "Blue 💙", "Yellow 💛"];
    result = colors[Math.floor(Math.random() * colors.length)];
  }

  document.getElementById("resultBox").textContent = result;
}
